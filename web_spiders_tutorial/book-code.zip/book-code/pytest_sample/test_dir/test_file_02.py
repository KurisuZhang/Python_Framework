
def test_case_02():
    assert (3 + 3) == 6
