

def test_case_01():
    assert (2 + 2) == 4


