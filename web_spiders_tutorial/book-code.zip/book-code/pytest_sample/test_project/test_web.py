

def test_baidu(test_url):
    print(test_url)
