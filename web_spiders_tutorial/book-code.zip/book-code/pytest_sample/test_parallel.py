from time import sleep


def test_01():
    sleep(3)


def test_02():
    sleep(5)


def test_03():
    sleep(6)

