
def test_fail_rerun():
    assert 2 + 2 == 5

