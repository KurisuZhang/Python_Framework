

# 失败
def test_fail():
    assert (2 + 1) == 4


# 成功
def test_success():
    assert (3 + 3) == 6
