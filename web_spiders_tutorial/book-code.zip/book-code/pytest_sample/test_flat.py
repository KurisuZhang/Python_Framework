
def test_flat():
    pass