

# 魅族社区APP配置
CAPS = {
    "deviceName": " MEIZU_E3",
    "automationName": "Appium",
    "platformName": "Android",
    "platformVersion": "7.1.1",
    "appPackage": " com.meizu.flyme.flymebbs",
    "appActivity": ".ui.LoadingActivity",
    "noReset": True,
    "unicodeKeyboard": True,
    "resetKeyboard": True,
}
