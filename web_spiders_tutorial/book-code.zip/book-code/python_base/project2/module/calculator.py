

# 创建add（）函数
def add(a, b):
    return a + b


if __name__ == '__main__':
    # 测试代码
    c = add(3, 5)
    print(c)
