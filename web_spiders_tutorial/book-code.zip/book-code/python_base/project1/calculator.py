

# 创建add（）函数
def add(a, b):
    return a + b
