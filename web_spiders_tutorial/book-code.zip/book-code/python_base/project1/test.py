# 导入calculator文件中的add函数
from calculator import add

print(add(4, 5))
