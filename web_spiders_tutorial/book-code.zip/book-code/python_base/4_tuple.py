"""
元组基本使用
"""
# 定义元组
tup1 = ('a', 'b', 3, 4)
tup2 = (1, 2, 3)

# 查看元组
print(tup1[0])
print(tup2[0:2])

# 连接元组
tup3 = tup1 + tup2
print(tup3)

# 元组复制
tup4 = ("Hi!")
print(tup4 * 3)
