"""
for 循环使用
"""

# 循环遍历字符串
for s in "hello":
    print(s)


# 循环遍历列表
fruits = ['banana', 'apple',  'mango']

for fruit in fruits:
    print(fruit)


# 循环遍历5次
for i in range(5):
    print(i)


# 打印1~10之间的奇数
for i in range(1, 10, 2):
    print(i)

