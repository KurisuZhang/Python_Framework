
# hello python
print("hello python")

# python打印
name = "tom"
age = 27
print("name is : " + name + ", age is : " + str(age))

print("name is : %s, age is : %d" %(name, age))

print("name is : {}, age is : {}".format(name, age))

print("name is : {1}, age is : {0}".format(age, name))

print("name is : {n}, age is : {a}".format(n=name, a=age))


# 引号与注释
print("hello")
print('world')
print("你说：'早上你好'")
print('我说："今天天气不错"')
# print("你微笑着'向我打招呼" .')
