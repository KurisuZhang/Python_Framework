"""
python哲学
"""

import this

print(this)
