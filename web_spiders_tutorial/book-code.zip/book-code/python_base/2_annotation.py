
# 单行注释
print("hell world")  # 打印hello world


"""
功能：自动化测试
作者：虫师
日期：2018-03-09
"""

'''
This is a
Multi line comment
'''